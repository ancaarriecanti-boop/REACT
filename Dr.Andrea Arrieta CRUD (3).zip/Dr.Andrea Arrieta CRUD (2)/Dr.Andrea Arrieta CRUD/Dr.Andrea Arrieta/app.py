from datetime import time as dtime, timedelta
from flask import Flask,jsonify, render_template, request, redirect, url_for, flash
import pymysql
import pymysql.cursors
from flask_cors import CORS
app = Flask(__name__)
CORS(app)

CORS(app, origins=["http://localhost:3000", "http://localhost:3000"])
app.secret_key = "cambia-esta-clave-por-una-segura" 
DB_CONFIG = dict(
    host="localhost",
    user="root",
    password="",
    database="arrieta",   
    charset="utf8mb4",
    cursorclass=pymysql.cursors.DictCursor,
)


def get_connection():
    return pymysql.connect(**DB_CONFIG)


@app.route("/")
def inicio():
    return render_template("index.html")


@app.route("/admin")
def admin():
    return render_template("admn.html")



@app.route("/pacientes")
def pacientes():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM pacientes ORDER BY apellido, nombre")
    lista_pacientes = cur.fetchall()
    cur.close()
    conn.close()
    return render_template("pacientes.html", pacientes=lista_pacientes)


@app.route("/pacientes/crear", methods=["POST"])
def crear_paciente():
    nombre = request.form["nombre"]
    apellido = request.form["apellido"]
    fecha_nacimiento = request.form.get("fechaNacimiento") or None
    sexo = request.form.get("sexo") or None

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO pacientes (nombre, apellido, fecha_nacimiento, sexo) VALUES (%s, %s, %s, %s)",
            (nombre, apellido, fecha_nacimiento, sexo),
        )
        conn.commit()
        cur.close()
        conn.close()
        flash("Paciente guardado correctamente.", "success")
    except Exception as e:
        flash(f"Ocurrió un error al guardar el paciente: {e}", "error")

    return redirect(url_for("pacientes"))


@app.route("/pacientes/eliminar/<int:id_paciente>", methods=["POST"])
def eliminar_paciente(id_paciente):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM pacientes WHERE id = %s", (id_paciente,))
        conn.commit()
        cur.close()
        conn.close()
        flash("Paciente eliminado.", "success")
    except Exception as e:
        flash(f"Ocurrió un error al eliminar el paciente: {e}", "error")

    return redirect(url_for("pacientes"))



@app.route("/profesionales")
def profesionales():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM profesionales ORDER BY apellido, nombre")
    lista_profesionales = cur.fetchall()
    cur.close()
    conn.close()
    return render_template("profesionales.html", profesionales=lista_profesionales)


@app.route("/profesionales/crear", methods=["POST"])
def crear_profesional():
    nombre = request.form["nombre"]
    apellido = request.form["apellido"]
    especialidad = request.form.get("especialidad") or None

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO profesionales (nombre, apellido, especialidad, activo) VALUES (%s, %s, %s, 1)",
            (nombre, apellido, especialidad),
        )
        conn.commit()
        cur.close()
        conn.close()
        flash("Profesional guardado correctamente.", "success")
    except Exception as e:
        flash(f"Ocurrió un error al guardar el profesional: {e}", "error")

    return redirect(url_for("profesionales"))


@app.route("/profesionales/eliminar/<int:id_profesional>", methods=["POST"])
def eliminar_profesional(id_profesional):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM profesionales WHERE id = %s", (id_profesional,))
        conn.commit()
        cur.close()
        conn.close()
        flash("Profesional eliminado.", "success")
    except Exception as e:
        flash(f"Ocurrió un error al eliminar el profesional: {e}", "error")

    return redirect(url_for("profesionales"))



@app.route("/tratamientos")
def tratamientos():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM pacientes ORDER BY apellido, nombre")
    lista_pacientes = cur.fetchall()
    cur.execute(
        """
        SELECT t.*, p.nombre AS paciente_nombre, p.apellido AS paciente_apellido
        FROM tratamientos t
        JOIN pacientes p ON p.id = t.id_paciente
        ORDER BY t.fecha_asignacion DESC
        """
    )
    lista_tratamientos = cur.fetchall()
    cur.close()
    conn.close()
    return render_template(
        "tratamientos.html", tratamientos=lista_tratamientos, pacientes=lista_pacientes
    )


@app.route("/tratamientos/crear", methods=["POST"])
def crear_tratamiento():
    id_paciente = request.form["id_paciente"]
    descripcion = request.form["descripcion"]
    fecha_asignacion = request.form["fecha_asignacion"]
    fecha_inicio = request.form["fecha_inicio"]
    fecha_fin = request.form.get("fecha_fin") or None

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO tratamientos (descripcion, fecha_asignacion, fecha_inicio, fecha_fin, id_paciente) "
            "VALUES (%s, %s, %s, %s, %s)",
            (descripcion, fecha_asignacion, fecha_inicio, fecha_fin, id_paciente),
        )
        conn.commit()
        cur.close()
        conn.close()
        flash("Tratamiento guardado correctamente.", "success")
    except Exception as e:
        flash(f"Ocurrió un error al guardar el tratamiento: {e}", "error")

    return redirect(url_for("tratamientos"))


@app.route("/tratamientos/eliminar/<int:id_tratamiento>", methods=["POST"])
def eliminar_tratamiento(id_tratamiento):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM tratamientos WHERE id = %s", (id_tratamiento,))
        conn.commit()
        cur.close()
        conn.close()
        flash("Tratamiento eliminado.", "success")
    except Exception as e:
        flash(f"Ocurrió un error al eliminar el tratamiento: {e}", "error")

    return redirect(url_for("tratamientos"))



@app.route("/citas")
def citas():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM pacientes ORDER BY apellido, nombre")
    lista_pacientes = cur.fetchall()
    cur.execute("SELECT * FROM profesionales ORDER BY apellido, nombre")
    lista_profesionales = cur.fetchall()
    cur.execute(
        """
        SELECT c.*,
               p.nombre AS paciente_nombre, p.apellido AS paciente_apellido,
               pr.nombre AS profesional_nombre, pr.apellido AS profesional_apellido
        FROM citas c
        JOIN pacientes p ON p.id = c.id_paciente
        JOIN profesionales pr ON pr.id = c.id_profesional
        ORDER BY c.fecha DESC, c.hora DESC
        """
    )
    lista_citas = cur.fetchall()
    cur.close()
    conn.close()
    
    for c in lista_citas:
        if isinstance(c["hora"], timedelta):
            total_segundos = int(c["hora"].total_seconds())
            horas, resto = divmod(total_segundos, 3600)
            minutos, segundos = divmod(resto, 60)
            c["hora"] = dtime(hour=horas % 24, minute=minutos, second=segundos)
    return render_template(
        "citas.html",
        citas=lista_citas,
        pacientes=lista_pacientes,
        profesionales=lista_profesionales,
    )


@app.route("/citas/crear", methods=["POST"])
def crear_cita():
    id_paciente = request.form["id_paciente"]
    id_profesional = request.form["id_profesional"]
    fecha = request.form["fecha"]
    hora = request.form["hora"]
    estado = request.form.get("estado") or "Programada"

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO citas (fecha, hora, estado, id_paciente, id_profesional) VALUES (%s, %s, %s, %s, %s)",
            (fecha, hora, estado, id_paciente, id_profesional),
        )
        conn.commit()
        cur.close()
        conn.close()
        flash("Cita guardada correctamente.", "success")
    except Exception as e:
        flash(f"Ocurrió un error al guardar la cita: {e}", "error")

    return redirect(url_for("citas"))


@app.route("/citas/eliminar/<int:id_cita>", methods=["POST"])
def eliminar_cita(id_cita):
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM citas WHERE id = %s", (id_cita,))
        conn.commit()
        cur.close()
        conn.close()
        flash("Cita eliminada.", "success")
    except Exception as e:
        flash(f"Ocurrió un error al eliminar la cita: {e}", "error")

    return redirect(url_for("citas"))

# Ruta para consulta json 
@app.route('/api/JUNIOR', methods=['GET']) 
def api_get_JUNIOR(): 
    try:
        conn = get_connection() 
        cur = conn.cursor()
        cur.execute("SELECT * FROM pacientes") 
        data = cur.fetchall() 
        cur.close() 
        conn.close() 
        return jsonify(data) 
    except Exception as e: 
        return jsonify({'error': str(e)}), 500




@app.route('/api/junior')
def api_junior():
    """Todas las citas, con nombres de paciente y profesional."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            """
            SELECT c.*,
                   p.nombre AS paciente_nombre, p.apellido AS paciente_apellido,
                   pr.nombre AS profesional_nombre, pr.apellido AS profesional_apellido
            FROM citas c
            JOIN pacientes p ON p.id = c.id_paciente
            JOIN profesionales pr ON pr.id = c.id_profesional
            ORDER BY c.fecha DESC, c.hora DESC
            """
        )
        filas = cur.fetchall()
        cur.close()
        conn.close()

        for c in filas:
            h = c.get("hora")
            if isinstance(h, timedelta):
                s = int(h.total_seconds())
                c["hora"] = f"{(s // 3600) % 24:02d}:{(s % 3600) // 60:02d}"
            elif h is not None:
                c["hora"] = str(h)[:5]
            if c.get("fecha") is not None:
                c["fecha"] = str(c["fecha"])[:10]

        return jsonify(filas)
    except Exception as e:
        print("Error en /api/junior:", e)
        return jsonify({"error": str(e)}), 500

    
@app.route('/api/tratamientos')
def api_tratamientos_lista():
    """Todos los tratamientos."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM tratamientos")
        filas = cur.fetchall()
        cur.close()
        conn.close()
        return jsonify(filas)
    except Exception as e:
        print("Error en /api/tratamientos:", e)
        return jsonify({"error": str(e)}, 500)
 
 
@app.route('/api/medicos')
def api_medicos():
    """Todos los médicos."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM profesionales")
        filas = cur.fetchall()
        cur.close()
        conn.close()
        return jsonify(filas)
    except Exception as e:
        print("Error en /api/medicos:", e)
        return jsonify({"error": str(e)}, 500)
if __name__ == "__main__":
    app.run(debug=True)
